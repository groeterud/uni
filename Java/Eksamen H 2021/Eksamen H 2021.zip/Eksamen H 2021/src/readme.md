## Dette er en liste over endringer gjort over tid. 

###oppgave 2d
* implementerte Comparable<Kamera> i Kamera klassen
* implementerte CompareTo metoden i Kamera klassen
* Endret konstruktør-parameter til megapixpler fra int til Integer for å kunne initialisere med null-merke

### oppgave 2e
* Endret konstruktør-parameter til pris fra double til Double for å kunne initialisere med null-merke. 
Oppgaveteksten spesifiserte ingen pris som parameter i metoden. Alternativet var at pris etterberegnes og ikke er en del 
av konstruktøren i det hele tatt. 
* La til metoden nyttUtleie() i Kunde-klassen for å legge ett utleie i ArrayListen.


### oppgave 3b
La til toString() på Kamera klassen for å kunne skrive ut data om kameraet.

### oppgave 3d/e
La til toString i klassene:
* Utleie
* Kunde
