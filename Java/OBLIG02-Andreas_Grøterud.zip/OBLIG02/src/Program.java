public class Program {
    public static void main(String[] args) {
        Grensesnitt grensesnitt = new Grensesnitt();
        grensesnitt.meny();
    }
}
