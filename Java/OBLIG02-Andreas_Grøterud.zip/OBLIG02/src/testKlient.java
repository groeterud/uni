public class testKlient {
    /*public static void main(String[] args) {
        Kontroll kontroll = new Kontroll();

        kontroll.nyGaupe("F",200.00,50.00, "20210515 20:33","Øvre havrevei 12",35.15);
        kontroll.nyGaupe("M",250.00,75.00,"20210610","Nydalssætra",42.00);
        kontroll.gjennFangstGaupe("G1","20210530","Hovdalssætra 14", 205.10,55.00,36.00);

        kontroll.nyHare("M",25.12,12.5,"20210101","S3","V","Lilla");
        kontroll.nyHare("F",23.12,09.5,"20212121","S4","S", "Brun");
        kontroll.gjennFangstHare("H1","20211001","S3",26.9,13.00,"Brun");

        System.out.println(kontroll.printHarer());
        System.out.println(kontroll.printGauper());

        System.out.println(kontroll.printAlleDyr());

        System.out.println(kontroll.printDyr("G1"));
    }

     */
}
